import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import java.io.IOException;

/** MiniSocial asset loader example; adapt UI draw logic to your MIDlet. */
public abstract class MiniSocialAssetsCanvas extends Canvas {
    protected String deviceFolder() {
        int w = getWidth(), h = getHeight();
        if (w >= 600 && h >= 420) return "e6";
        if (w >= 600 && h >= 320) return "wide";
        return "e72";
    }
    protected Image loadUi(String group, boolean dark, String file) throws IOException {
        return Image.createImage("/assets/" + deviceFolder() + "/v2/" + group +
                                 "/" + (dark ? "dark" : "light") + "/" + file + ".png");
    }
    protected void drawAsset(Graphics g, Image img, int x, int y) {
        if (img != null) g.drawImage(img, x, y, Graphics.TOP | Graphics.LEFT);
    }
    protected void drawCaption(Graphics g, String content, int x, int y) {
        g.setColor(0x152740);
        g.drawString(content, x, y, Graphics.TOP | Graphics.LEFT);
    }
}

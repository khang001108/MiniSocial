MINISOCIAL JAVA ME — UI ASSETS v2.0 (EXTENSION OF UPLOADED v1 ZIP)

ĐÃ GIỮ NGUYÊN FILE CŨ
- Toàn bộ 607 PNG gốc của v1.0 không bị sửa hoặc xóa.
- Thư mục e72/ và e6/ vẫn giữ nguyên các đường dẫn cũ.

THÊM MỚI
- wide/ : bộ 640x360, dùng cho màn hình ngang; thanh và nền có kích thước phù hợp.
- e72/v2/, wide/v2/, e6/v2/: 6 nhóm asset, 2 chủ đề light/dark.
- Mỗi file PNG là một ảnh riêng, nền trong suốt đối với các thành phần/đối tượng.
- 6 nhóm: messenger, social_feed, profile, notifications, settings, system.
- preview/v2_overview.png: ảnh xem trước tổng hợp; preview/v2/screens/: preview đúng 3 kích thước.
- preview/*.jpg: bản tham chiếu thiết kế, KHÔNG đưa các file này vào JAR.

ĐƯỜNG DẪN TÀI NGUYÊN (MẶC ĐỊNH TRONG JAR)
Đặt các thư mục e72/, wide/, e6/ bên trong /assets tại gốc của JAR.
Ví dụ:
  /assets/e72/v2/messenger/light/chat_row.png
  /assets/wide/v2/social_feed/light/post_text_card.png
  /assets/e6/v2/settings/dark/toggle_on.png

CHỌN MÀN HÌNH — CHÚ Ý 640x360 và 640x480 có cùng chiều rộng:
  String device;
  if (getWidth() >= 600 && getHeight() >= 420) device = "e6";
  else if (getWidth() >= 600 && getHeight() >= 320) device = "wide";
  else device = "e72";

  Image img = Image.createImage("/assets/"+device+"/v2/messenger/light/chat_row.png");
  g.drawImage(img, x, y, Graphics.LEFT | Graphics.TOP);

THỰC TẾ KHI LÀM JAVA ME
- Các ảnh v2 là component TRỐNG có thể vẽ chữ/dữ liệu thật lên bằng Graphics.drawString.
- PNG không phải code giao diện hay ứng dụng hoàn chỉnh; cần lập trình Canvas và điều khiển phím.
- Không nhúng ảnh preview vào JAR. Trên E72 chỉ đưa assets thực tế đang dùng để tiết kiệm bộ nhớ.
- Dùng 9-slice hoặc Canvas để kéo dãn thẻ chat và ô nhập; không stretch cả ảnh nền khi thay chiều dài.
- Động hình spinner/typing: đổi frame trong vòng lặp Canvas, ví dụ spinner_00 đến spinner_07.
- Khi chuyển màn, giải phóng các Image không dùng; chỉ giữ tối đa số lượng cần trên màn hình.
- Tham khảo manifest.json để biết kích thước PNG, màu, tên file, chủ đề.

BẢN QUYỀN
- Giữ ATTRIBUTION.txt v1.0 khi sử dụng icon có nguồn Font Awesome 4.7.0.
- Bộ thành phần v2 được vẽ bằng code gốc; các ảnh thiết kế JPG chỉ để tham khảo.
